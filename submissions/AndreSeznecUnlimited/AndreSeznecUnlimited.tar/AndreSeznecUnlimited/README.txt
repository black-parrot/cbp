Andre Seznec,  IRISA/INRIA, andre.seznec@inria.fr
Conflicts: Pierre Michaud, colloaborator with in the same group
Moinuddin Qureshi, coauthor at HPCA 2011

Submission to the unlimited track
